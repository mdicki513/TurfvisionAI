document.getElementById('leadForm').addEventListener('submit', function(e) {
  e.preventDefault();
  document.getElementById('responseMsg').innerText = 'Thank you! We received your message.';
  this.reset();
});
