import React from "react";
import LeadForm from "./components/LeadForm";
function App() {
  return (
    <div>
      <h1>TurfVision AI™ by BBTURFCO</h1>
      <LeadForm />
    </div>
  );
}
export default App;
